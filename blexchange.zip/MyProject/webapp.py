from flask import Flask, render_template as rt, request, session, redirect
from DBcm import UseDB


app = Flask(__name__)
app.config['db'] = {'host':'127.0.0.1', 'user':'incharge', 'database':'dbexchange', 'password':'iamincharge'}
app.secret_key = 'Thisisnotyourapp'

@app.route('/')
def home():
    if 'logged_in' in session:
        return rt('index.html', link1 = "LINKS", link2= "MY PROFILE ", route1 = '/login', route2 = '/signup')
    return rt('index.html', link1 = "LOGIN", link2= "SIGNUP ", route1 = '/login', route2 = '/signup')
    

@app.route('/signup', methods=['POST', 'GET'])
def do_signup():
    if request.method == 'POST':
        data = (request.form['name'], request.form['email'], request.form['username'], request.form['password'], request.remote_addr, request.user_agent.browser)
        with UseDB(app.config['db']) as cursor:
            _SQL = '''select email from users_info'''
            cursor.execute(_SQL)
            emails = cursor.fetchall()
            for email in emails:
                if email[0] == data[1]:
                    return 'Email has been used by another user'
                else:
                    pass
            if data[3] != request.form['confirm_password']:
                return 'Re-confirm your password!'
            elif '.com' not in data[1]:
                return 'Go back to re-confirm your email'
            else:
                _SQL = '''INSERT INTO users_info (Name, email, username, password, IP, browser_string)
                        values(%s, %s, %s, %s, %s, %s)
                    '''
                cursor.execute(_SQL, data)
                session['logged_in'] = True
                return redirect('/')

    return rt('signup.html')

@app.route('/login', methods=['POST', 'GET'])
def do_login():
    if request.method == 'POST':
        try:
            with UseDB(app.config['db']) as cursor:
                data = (request.form['email'], request.form['password'])
                _SQL = '''SELECT email, password from users_info where email=%s
                        '''
                cursor.execute(_SQL, (data[0],))
                info = cursor.fetchall()
                if info[0][1] == data[1]:
                    session['logged_in'] = True
                    return redirect('/')
                return 'Check login details and try again'
        except Exception as err:
            return 'Account not created. <a href="/signup">Sign up here</a>'
    return rt('login.html')

@app.route('/logout')
def do_logout():
    if 'logged_in' in session:
        del session['logged_in']
        return 'You are logged out'
    return "You're not logged in"
@app.route('/data')

def data():
    with UseDB(app.config['db']) as cursor:
        _SQL = '''select email from users_info'''
        cursor.execute(_SQL)
        return str(cursor.fetchall())


@app.route('/link')
def links():
    return rt('links.html')


if __name__ == '__main__':
    app.run(debug=True)