from flask import Flask, session, request
from functools import wraps
from DBcm import UseDB

app = Flask(__name__)

app.config['db'] = {'host':'127.0.0.1', 'user':'incharge', 'database':'dbexchange', 'password':'iamincharge'}

with UseDB(app.config['db']) as cursor:
    data = (request.form['email'], request.form['password'], request.form['confirm_password'],)
    _SQL = '''select email form users_info'''
    cursor.execute(_SQL)
    emails = cursor.fetchall()

def check(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if request.method == 'POST':
            for email in emails:
                if data[0] == email:
                    return 'Email is been used by another user. Try another email'
                pass
            if data[1] == data[2]:
                return func(*args, **kwargs)
            return 'Re-confirm your password and try again'
    return wrapper


